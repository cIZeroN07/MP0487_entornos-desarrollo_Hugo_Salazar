// Pizzeria Configuration - Fixed Text Strings
class PizzaConfig {
  static const String welcomeMsg =
      "=== Welcome to the Mario Bros Pizzeria Terminal ===";
  static const String menuHeader = "--- PIZZA APP MENU ---";
  static const String option1 = "1. View Menu & Prices";
  static const String option2 = "2. Add Pizza to Order Cart";
  static const String option3 = "3. View Current Cart";
  static const String option4 = "4. Checkout & Print Receipt";
  static const String option5 = "5. Cancel Order and Exit";
  static const String selectPrompt = "Select options (1-5): ";
  static const String pizzaMenuHeader = "🍕 --- Our Pizza Menu ---";
  static const String basePriceNote =
      "Note: Medium size adds \$2.00, Large adds \$4.00.";
  static const String selectPizzaMsg = "Select a Pizza Style:";
  static const String enterPizzaChoice = "Enter Choice (1-";
  static const String sizeSelectionMsg =
      "Select Size:\n  S. Small (Base)\n  M. Medium (+\$2.00)\n  L. Large (+\$4.00)";
  static const String sizePrompt = "Enter preference (S/M/L): ";
  static const String invalidSelectionMsg =
      "❌ Invalid selection. Pizza item not added.";
  static const String smallSize = "Small";
  static const String mediumSize = "Medium";
  static const String largeSize = "Large";
  static const String unrecognizedSizeMsg =
      "⚠️ Unrecognized size option. Defaulting to Small.";
  static const String addedToCartMsg = "✅ Added: ";
  static const String toYourCart = " to your cart!";
  static const String cartHeader = "🛒 --- Your Current Order Cart ---";
  static const String emptyCartMsg = "Your cart is completely empty.";
  static const String itemFormat = " - Item ";
  static const String checkoutHeader = "🧾 --- Finalizing Transaction ---";
  static const String checkoutFailedMsg =
      "❌ Checkout failed. Cannot check out with an empty cart.";
  static const String receiptBorder = "===============================";
  static const String pizzeriaName = "      SLICE & DICE PIZZERIA    ";
  static const String receiptDivider = "-------------------------------";
  static const String subtotalLabel = "Subtotal:         \$";
  static const String taxLabel = "Tax (8%):         \$";
  static const String grandTotalLabel = "GRAND TOTAL:      \$";
  static const String thankYouMsg = "  Thank you for your business! ";
  static const String newOrderPrompt =
      "Would you like to start a new order? (Y/N): ";
  static const String exitMsg = "Exiting system. Have a great day!";
  static const String cancelMsg =
      "Closing registers down. Order execution sequence aborted.";
  static const String invalidInstructionMsg =
      "❌ Invalid instruction entered. Choose 1 through 5.";
}

// Shipment Tracking Configuration
class ShipmentConfig {
  static const String welcomeMsg =
      "=== Welcome to the Shipment Tracking System ===";
  static const String menuHeader = "--- MAIN MENU ---";
  static const String option1 = "1. View All Shipments";
  static const String option2 = "2. Track a Shipment by ID";
  static const String option3 = "3. Update Shipment Status";
  static const String option4 = "4. Add New Shipment";
  static const String option5 = "5. Calculate Total Shipping Weight";
  static const String option6 = "6. Display Heaviest Shipment";
  static const String option7 = "7. Exit";
  static const String selectPrompt = "Please enter your choice (1-7): ";
  static const String viewHeader = "--- Current Shipments ---";
  static const String heaviestHeader = "🏋️ --- Heaviest Shipment ---";
  static const String emptyMsg = "No shipments found in the system.";
  static const String shipmentFormat = "ID: ";
  static const String destLabel = " | Destination: ";
  static const String statusLabel = " | Status: ";
  static const String weightLabel = " | Weight: ";
  static const String kgUnit = " kg";
  static const String trackPrompt = "Enter Shipment ID to track: ";
  static const String invalidInputMsg = "❌ Invalid input! ID must be a number.";
  static const String foundMsg = "📦 Shipment Found!";
  static const String notFoundMsg = "❌ Shipment ID not found.";
  static const String updatePrompt = "Enter Shipment ID to update: ";
  static const String invalidMsg = "❌ Invalid input.";
  static const String currentStatusMsg = "Current Status: ";
  static const String statusOptionsMsg =
      "Select New Status:\n  A. Processing\n  B. In Transit\n  C. Out for Delivery\n  D. Delivered";
  static const String statusChoicePrompt = "Enter choice (A/B/C/D): ";
  static const String processingStatus = "Processing";
  static const String inTransitStatus = "In Transit";
  static const String outForDeliveryStatus = "Out for Delivery";
  static const String deliveredStatus = "Delivered";
  static const String invalidStatusMsg =
      "⚠️ Invalid status selection. No changes made.";
  static const String updateSuccessMsg = "✅ Status successfully updated to: ";
  static const String idNotFoundMsg = "❌ Shipment ID not found.";
  static const String newIdPrompt = "Enter New Shipment ID (Numeric): ";
  static const String destPrompt = "Enter Destination: ";
  static const String weightPrompt = "Enter Weight (kg): ";
  static const String duplicateMsg =
      "❌ Error: A shipment with ID already exists.";
  static const String addSuccessMsg = "✅ Shipment successfully added!";
  static const String invalidEntriesMsg =
      "❌ Invalid entries. Unable to create shipment.";
  static const String totalWeightMsg =
      "⚖️ Total weight of all shipments in system: ";
  static const String exitMsg = "Exiting system. Goodbye!";
  static const String invalidOptionMsg =
      "❌ Invalid menu option. Please select 1 through 7.";
}

// Bus Tracker Configuration
class BusTrackerConfig {
  static const String welcomeMsg =
      "=== Welcome to the City Bus Stop Tracker ===";
  static const String menuHeader = "--- BUS TRACKER MENU ---";
  static const String option1 = "1. View All Active Buses";
  static const String option2 = "2. Search Buses by Stop Name";
  static const String option3 =
      "3. Update Bus Arrival Times (Simulate Time Progress)";
  static const String option4 = "4. Add a Bus to a Stop Schedule";
  static const String option5 = "5. Check Next Closest Bus (Any Stop)";
  static const String option6 = "6. Calculate Average Arrival Time (All Buses)";
  static const String option7 = "7. Exit";
  static const String selectPrompt = "Enter your choice (1-7): ";
  static const String scheduleHeader = "--- Current Bus Schedule Matrix ---";
  static const String averageMsg = "📊 Average arrival time across all buses: ";
  static const String noSchedulesMsg = "No buses are currently scheduled.";
  static const String stopLabel = " | Stop: ";
  static const String arrivalLabel = " | Arriving in: ";
  static const String minsLabel = " mins";
  static const String searchPrompt =
      "Enter Stop Name to look up (e.g., Downtown): ";
  static const String invalidInputMsg =
      "❌ Invalid input. Stop name cannot be blank.";
  static const String boardHeader = "🚏 Live Board for stop: ";
  static const String busFormat = " - ";
  static const String arrivingMsg = " arriving in ";
  static const String minutesMsg = " minutes.";
  static const String noBusesMsg = "No buses are currently heading to ";
  static const String timePrompt = "How many minutes have passed? ";
  static const String invalidTimeMsg =
      "❌ Invalid value. Please enter a positive number of minutes.";
  static const String advancingMsg = "⏱️ Advancing time by ";
  static const String minutesSuffix = " minutes...";
  static const String departedMsg = "🚌 ";
  static const String departedFromMsg = " has departed from ";
  static const String updatedMsg = "✅ Schedules updated.";
  static const String busPrompt = "Enter Bus Line Code (e.g., Line 14): ";
  static const String stopPrompt = "Enter Target Stop Name: ";
  static const String etaPrompt = "Enter ETA (Minutes until arrival): ";
  static const String addSuccessMsg = "✅ Successfully scheduled ";
  static const String toStopMsg = " to stop at ";
  static const String validationFailMsg =
      "❌ Input validation failed. Bus route not saved.";
  static const String noBusesGridMsg = "No active buses on the grid.";
  static const String nextBusMsg = "🚨 Next upcoming arrival:";
  static const String busLabel = "Bus: ";
  static const String atStopLabel = " at Stop: ";
  static const String minsAwayMsg = " mins away)";
  static const String exitMsg = "Shutting down tracker. Safe travels!";
  static const String invalidChoiceMsg =
      "❌ Invalid menu choice. Enter a number between 1 and 7.";
}

// Hotel Configuration
class HotelConfig {
  static const String welcomeMsg =
      "=== Welcome to the Grand Horizon Hotel Management System ===";
  static const String menuHeader = "--- FRONT DESK MENU ---";
  static const String option1 = "1. View All Rooms Status";
  static const String option2 = "2. Book/Check-In a Guest";
  static const String option3 = "3. Check-Out a Guest (Generate Bill)";
  static const String option4 = "4. Filter Available Rooms by Budget";
  static const String option5 = "5. Calculate Current Total Revenue Potential";
  static const String option6 = "6. Exit";
  static const String selectPrompt = "Enter command (1-6): ";
  static const String roomHeader = "--- Room Status Directory ---";
  static const String availableStatus = "AVAILABLE";
  static const String occupiedStatus = "OCCUPIED (Guest: ";
  static const String roomFormat = "Room ";
  static const String roomTypeFormat = " [";
  static const String rateFormat = "] - \$";
  static const String nightLabel = "/night | Status: ";
  static const String bookPrompt = "Enter Room Number to book: ";
  static const String invalidInputMsg =
      "❌ Invalid entry. Room must be a number.";
  static const String occupiedMsg = "❌ Sorry, Room ";
  static const String occupiedByMsg = " is already occupied by ";
  static const String guestPrompt = "Enter Guest Name: ";
  static const String checkInSuccessMsg = "✅ Success! Room ";
  static const String checkInToMsg = " is now checked-in to ";
  static const String emptyNameMsg = "❌ Guest name cannot be empty.";
  static const String roomNotFoundMsg = "❌ Room number ";
  static const String doesNotExistMsg = " does not exist in our hotel.";
  static const String checkoutPrompt = "Enter Room Number checking out: ";
  static const String invalidConfigMsg = "❌ Invalid room configuration.";
  static const String emptyRoomMsg = "⚠️ Room ";
  static const String emptyWarningMsg =
      " is already empty. No checkout needed.";
  static const String nightsPrompt = "How many nights did they stay? ";
  static const String invoiceHeader = "🧾 --- INVOICE ---";
  static const String guestLabel = "Guest: ";
  static const String roomLabel = "Room: ";
  static const String stayLabel = "Total Stay: ";
  static const String nightsLabel = " nights x \$";
  static const String amountLabel = "Amount Due: \$";
  static const String invoiceDivider = "-------------------";
  static const String checkoutSuccessMsg = "✅ Checkout complete. Room ";
  static const String cleanAvailableMsg = " is now clean and available.";
  static const String notFoundMsg = "❌ Room ";
  static const String roomNotExistMsg = " not found.";
  static const String budgetPrompt =
      "Enter maximum nightly price comfort limit (\$): ";
  static const String budgetErrorMsg =
      "❌ Please enter a realistic budget figure.";
  static const String budgetResultMsg = "💸 Matches under \$";
  static const String openMsg = " that are currently open:";
  static const String roomResultFormat = " - Room ";
  static const String roomTypeResultMsg = " (";
  static const String rateResultMsg = ") at \$";
  static const String noMatchMsg =
      "No matching available rooms found within your budget range.";
  static const String financialHeader = "💰 --- Financial State ---";
  static const String occupiedRevenueMsg =
      "Live Nightly Revenue (Occupied Rooms): \$";
  static const String maxRevenueMsg =
      "Maximum Potential Value (All Rooms Booked): \$";
  static const String exitMsg = "Closing the reception terminal... Good night.";
  static const String unknownCommandMsg =
      "❌ Unknown command selection. Retrying menu pipeline.";
}

// Parking Lot Configuration
class ParkingConfig {
  static const String welcomeMsg =
      "=== Welcome to the Smart Parking Lot Terminal ===";
  static const String menuHeader = "--- PARKING TERMINAL MENU ---";
  static const String option1 = "1. View Parking Lot Layout";
  static const String option2 = "2. Park a Car (Check-In)";
  static const String option3 = "3. Retrieve Car & Pay (Check-Out)";
  static const String option4 =
      "4. Find Free Spots by Type (EV, Handicap, etc.)";
  static const String option5 = "5. Exit System";
  static const String selectPrompt = "Select an option (1-5): ";
  static const String mapHeader = "--- Live Parking Map ---";
  static const String availableStatus = "🟢 AVAILABLE";
  static const String occupiedStatus = "🔴 OCCUPIED [Car: ";
  static const String spotFormat = "Spot ";
  static const String typeFormat = " (";
  static const String statusFormat = ") -> ";
  static const String summaryMsg = "Summary: ";
  static const String outOfMsg = " out of ";
  static const String availableMsg = " spots are available.";
  static const String parkPrompt = "Enter Spot Number to park in: ";
  static const String invalidInputMsg =
      "❌ Invalid entry. Spot must be a number.";
  static const String takenMsg = "❌ Spot ";
  static const String takenWarningMsg = " is already taken!";
  static const String platePrompt = "Enter Car License Plate: ";
  static const String hourPrompt = "Enter Current Hour (0-23): ";
  static const String parkSuccessMsg = "✅ Car ";
  static const String parkedAtMsg = "' successfully parked in Spot ";
  static const String atHourMsg = " at hour ";
  static const String timeFormat = ":00.";
  static const String invalidPlateMsg =
      "❌ Invalid plate or invalid 24-hour timestamp.";
  static const String spotNotExistMsg = "❌ Parking Spot ";
  static const String spotNotExistWarningMsg = " does not exist.";
  static const String retrievePrompt =
      "Enter License Plate or Spot Number to leave: ";
  static const String emptyInputMsg = "❌ Input cannot be empty.";
  static const String emptySpotMsg = "⚠️ Spot ";
  static const String emptySpotWarningMsg = " is already empty.";
  static const String exitHourPrompt = "Enter Current Departure Hour (0-23): ";
  static const String receiptHeader = "🧾 --- PARKING RECEIPT ---";
  static const String plateLabel = "Car Plate: ";
  static const String spotLabel = "Spot Used: ";
  static const String timeLabel = "Time Parked: From ";
  static const String toLabel = ":00 to ";
  static const String hoursLabel = ":00 (";
  static const String hoursSuffix = " hours)";
  static const String rateLabel = "Rate: \$";
  static const String perHourMsg = " / hr";
  static const String feeLabel = "Total Fee Due: \$";
  static const String receiptDivider = "--------------------------";
  static const String paymentSuccessMsg = "✅ Payment processed. Spot ";
  static const String vacantMsg = " is now vacant.";
  static const String noCarMsg =
      "❌ No active parked car matches standard identifier: ";
  static const String filterHeader =
      "Select Type to Filter:\n1. Standard\n2. Compact\n3. EV Charging\n4. Handicap";
  static const String filterPrompt = "Enter choice (1-4): ";
  static const String standardType = "Standard";
  static const String compactType = "Compact";
  static const String evType = "EV Charging";
  static const String handicapType = "Handicap";
  static const String invalidSelectionMsg = "❌ Invalid selection choice.";
  static const String filterResultMsg = "🔍 Available ";
  static const String spotsMsg = "' spots:";
  static const String spotListMsg = " - Spot ";
  static const String noSpotsMsg = "No open slots found for category: ";
  static const String exitMsg =
      "Shutting down the parking grid database. Goodbye!";
  static const String invalidActionMsg =
      "❌ Invalid action item. Use keys 1 through 5.";
}
